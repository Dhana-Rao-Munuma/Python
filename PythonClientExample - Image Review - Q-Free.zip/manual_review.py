import copy
import time
import requests
from zeep import Transport, Client
from zeep.exceptions import Fault

# The username that is used to connect to Intrada Insight
username = '[USERNAME]'

# The password that corresponds with the username
password = '[PASSWORD]'

# The url of the Manual Review Service. [Intrada Insight URL] is a placeholder of the URL that point to the Intrada Insight
# installation
iss_url = 'https://[Intrada Insight URL]/ManualReviewService.wsdl'

# The manual queue of which the tasks should be retrieved. For example 'default'
manual_queue = '[QUEUE]'

# The maximum number of manual tasks that should be retrieved at the same time
batch_size = 10


class ManualReview:
    """Manual review code integration example"""

    def __init__(self):
        """Initialize an instance of ManualReview

        This methods creates a client with the provided credentials and connects this client to the Intrada Synergy
        Server instance that is hosted on the provided URL. Additional types are imported by type factories in order to
        easy the creation of types that are required by Intrada Insight.
        """

        session = requests.Session()
        session.auth = requests.auth.HTTPBasicAuth(username, password)
        transport = Transport(session=session)
        self.client = None

        try:
            self.client = Client(iss_url, transport=transport)
            print('Created client')
        except requests.exceptions.HTTPError as http_error:
            print('Could not create client due to HTTPError: {0}'.format(http_error))

        self.factory_xsd_common = self.client.type_factory('ns1')
        self.factory_xsd_manual_review = self.client.type_factory('ns2')

    def run(self):
        """Run the ManualReview client

        This method retrieves tasks from Intrada Insight, sends acknowledgements of these tasks to Intrada Insight, creates results for these
        tasks and sends the results of these tasks to Intrada Insight.
        """

        try:
            # Retrieve tasks
            tasks = self.get_tasks(manual_queue, batch_size)

            # Acknowledge tasks
            acknowledged_tasks = self.acknowledge_tasks(tasks)

            # Create results
            results = self.process_tasks(acknowledged_tasks)

            # Send the results
            self.complete_tasks(results)
        except Fault as fault:
            print(fault.message)
            print(" {}".format(fault.code))

            if fault.detail is not None:
                self.print_node(fault.detail)

    def print_node(self, node):
        """Recursively print the text of every node

        :param node: The node
        """

        for child_node in node:
            self.print_node(child_node)

        if node.text is not None:
            print(node.text)

    def get_tasks(self, queue, max_tasks):
        """Retrieve new manual review tasks from Intrada Insight

        :param queue: The queue where the tasks should be retrieved from
        :type queue: str
        :param max_tasks: The maximum number of tasks that Intrada Insight should send
        :type max_tasks: int
        :return: A list of manual review tasks
        :rtype: list
        """

        print('Retrieving tasks')
        tasks = self.client.service.GetTasks(Queue=queue, MaxTasks=max_tasks)
        print('Received {} tasks'.format(len(tasks)))

        return tasks

    def acknowledge_tasks(self, tasks):
        """Acknowledge the given tasks

        This method returns all the tasks that have been successfully acknowledged. When processing, use these tasks.
        You do not need to process rejected tasks.

        :param tasks: The received tasks
        :type tasks: list
        :raises ValueError: When an acknowledgement status that has been received from Intrada Insight is not in OK, REJECT or RETRY
        :return: Acknowledged manual review tasks
        :rtype: list
        """

        acknowledgements = list(map(lambda task: {
            'IssTaskID': task['IssTaskID'],

            # The status dictates whether this client accepts the task. The status "OK" means that this client accepted
            # the task, "RETRY" that Intrada Insight should send the task again and "REJECT" that this client
            # does not accept the task and that Intrada Insight should not send it in the future. Reject can be
            # used for when this client does not recognize the task type for example.
            '_value_1': 'OK'}, tasks))

        # Copy acknowledgements into a new list so that the we can alter this list while keeping the original list
        to_be_acknowledged = copy.deepcopy(acknowledgements)

        acknowledged_tasks = []

        while len(to_be_acknowledged) > 0:

            acknowledgement_results = self.client.service.AcknowledgeTasks(Acknowledgement=to_be_acknowledged)

            to_be_acknowledged = []

            # Check the status of every send acknowledgement and act accordingly
            for acknowledgement_result in acknowledgement_results:
                status = acknowledgement_result._value_1

                if status == 'OK':
                    # When the status is "OK", the task has been successfully been acknowledged. This task is therefore
                    # ready for processing.
                    print("Successfully acknowledged task with IssTaskID '{}'".format(acknowledgement_result.IssTaskID))

                    acknowledged_tasks.append(
                        next(task for task in tasks if task['IssTaskID'] == acknowledgement_result.IssTaskID))
                    continue

                if status == 'REJECT':
                    # The status is "REJECT": This usually means that the data is invalid. You should do error handling
                    # here. See acknowledgeResult.Description for more detailed information on the error.
                    print("Could not acknowledge task with IssTaskID '{}': {}".format(
                        acknowledgement_result.IssTaskID, acknowledgement_result.Description))
                    continue

                if status == "RETRY":
                    # A retry status means that the data was valid, but that Intrada Insight could not process the data right now.
                    # As such, we should try to resend the acknowledgement.
                    print("Scheduling acknowledgement for task with IssTaskID '{}' for retry"
                          .format(acknowledgement_result.IssTaskID))

                    to_be_acknowledged.append(
                        next(ack for ack in acknowledgements if ack['IssTaskID'] == acknowledgement_result.IssTaskID))

                    continue

                # Received a status from Intrada Insight that is not in OK, REJECT or RETRY
                raise ValueError('Unexpected acknowledgement status: {}'.format(status))

            # If we scheduled acknowledgements for a retry, sleep and try to send them again
            if len(to_be_acknowledged) > 0:
                time.sleep(1)

        return acknowledged_tasks

    def process_tasks(self, tasks):
        """Process the given tasks

        :param tasks: Tasks that have to be processed
        :type tasks: list
        :return: Results for given tasks
        :rtype: list
        """

        # TODO: Implement your own processing here

        results = []

        for task in tasks:
            result = self.factory_xsd_manual_review.TaskResultType(
                IssTaskID=task.IssTaskID,
                MetadataItem=[
                    # For this task we set some metadata properties as required by our demo business rules. Beware that
                    # the requirements on the metadata items might change on a per project basis.
                    self.factory_xsd_common.MetadataItemType(
                        Key='Registration',
                        Value=''
                    ),
                    self.factory_xsd_common.MetadataItemType(
                        Key='Jurisdiction',
                        Value=''
                    ),
                    self.factory_xsd_common.MetadataItemType(
                        Key='PlateType',
                        Value=''
                    )
                ],

                # This example rejects all tasks by default because its only function is to demonstrate how you could
                # integrate your MIR client with Intrada Insight.
                Reject='Rejected by MIR example code'
            )

            results.append(result)

        return results

    def complete_tasks(self, results):
        """Send the task results to Intrada Insight

        :param results: The results that have to be send to Intrada Insight
        :raises ValueError: When an acknowledgement status that has been received from Intrada Insight is not in OK, REJECT or RETRY
        """

		# Copy results into a new list so that the we can alter this list while keeping the original list.
        results_to_be_send = copy.deepcopy(results)

        while len(results_to_be_send) > 0:
            acknowledgements = self.client.service.CompleteTasks(TaskResult=results_to_be_send)

            results_to_be_send = []

            # Check the status of every send acknowledgement and act accordingly
            for acknowledgement in acknowledgements:
                status = acknowledgement._value_1

                if status == 'OK':
                    # When the status is "OK", the result has been accepted. There is nothing you should do
                    # here.
                    print("Result for task with IssTaskID '{}' was accepted".format(acknowledgement.IssTaskID))
                    continue

                if status == 'REJECT':
                    # The status is "REJECT": This usually means that the data is invalid. You should do error handling
                    # here. See acknowledgement.Description for more detailed information on the error.
                    print("Result for task with IssTaskID '{}' was rejected: {}"
                          .format(acknowledgement.IssTaskID, acknowledgement.Description))
                    continue

                if status == "RETRY":
                    # A retry status means that the data was valid, but that Intrada Insight could not process the data right now.
                    # As such, we should try to resend the result.
                    print("Schedule sending result for task with IssTaskID '{}' for retry"
                          .format(acknowledgement.IssTaskID))

                    results_to_be_send.append(
                        next(result for result in results if result['IssTaskID'] == acknowledgement.IssTaskID))

                    continue

                # Received a status from Intrada Insight that is not in OK, REJECT or RETRY
                raise ValueError('Unexpected acknowledgement status: {}'.format(status))

            # If we scheduled sending results for a retry, sleep and try to send them again
            if len(results_to_be_send) > 0:
                time.sleep(1)


if __name__ == '__main__':
    try:
        manual_review_client = ManualReview()
        manual_review_client.run()
    except Exception as e:
        print(e)
    finally:
        print('Press enter to close the application.')
        input()
