import requests
from zeep import Client
from zeep import Transport
import datetime
import uuid
import copy
import time

from zeep.exceptions import Fault

# The username that is used to connect to Intrada Insight
username = '[USERNAME]'

# The password that corresponds with the username
password = '[PASSWORD]'

# The url of the Passage Service. [Intrada Insight URL] is a placeholder of the URL that point to the Intrada Insight
# installation
iss_url = 'https://[Intrada Insight URL]/PassageService.wsdl'

# Location of a JPG image
image_location = '[IMAGE LOCATION]'

#  Url of an image
image_url = 'https://my.webserver.com/plate.jpg'


class EnqueuePassages:
    """PassageService.EnqueuePassages code integration example"""

    def __init__(self):
        """Initialize an instance of EnqueuePassages

        This methods creates a client with the provided credentials and connects this client to the Intrada Synergy
        Server instance that is hosted on the provided URL. Additional types are imported by type factories in order to
        ease the creation of types that are required by Intrada Insight.
        """

        session = requests.Session()
        session.auth = requests.auth.HTTPBasicAuth(username, password)
        transport = Transport(session=session)
        self.client = None

        try:
            self.client = Client(iss_url, transport=transport)
            print('Created client')
        except requests.exceptions.HTTPError as http_error:
            print('Could not create client due to HTTPError: {0}'.format(http_error))

        self.factory_xsd_common = self.client.type_factory('ns1')
        self.factory_xsd_passage = self.client.type_factory('ns2')

    def run(self):
        """Run the PassageService.EnqueuePassages client

        This method builds passages and sends these passages to Intrada Insight.
        """

        try:
            passages = self.build_passages()
            self.enqueue_passages(passages)
        except Fault as fault:
            print(fault.message)
            print(fault.code)

            if fault.detail is not None:
                self.print_node(fault.detail)

    def print_node(self, node):
        """Recursively print the text of every node

        :param node: The node
        """

        for child_node in node:
            self.print_node(child_node)

        if node.text is not None:
            print(node.text)

    def build_passages(self):
        """Build a list with one passage

        :return: A list with one passage
        :rtype: list
        """

        passage = self.factory_xsd_passage.PassageType(
            CaptureTimeUTC=datetime.datetime.now(datetime.timezone.utc),

            # The HostPassageID is a field in which Intrada Insight allows you to fill in your unique identifier
            # for the passage that will be submitted. Intrada Insight will assign its own identifier to this passage, but will
            # provide the HostPassageID as part of the result, to make it easier to search for your passage.
            HostPassageID=str(uuid.uuid4()),

            # The source can be used when retrieving the time horizon. This field is optional.
            Source='[SOURCE]',

            # A passage contains one or multiple images. The image-data can be placed inside:
            #     1) The URL-field: This is the location of an image-file
            #         (https://en.wikipedia.org/wiki/URL).
            #     2) The Data-field: This field should contain the binary data
			#        of an image (raw bytes).
            Image=[
                self.factory_xsd_common.ImageType(
                    Uri=image_url,
                    MetadataItem=[self.factory_xsd_common.MetadataItemType(
                        Key='KeyExample',
                        Value='ValueExample',
                        Target=self.factory_xsd_common.TargetEnumeration("MIR")
                    )]
                ),
                self.factory_xsd_common.ImageType(
                    Data=open(image_location, 'rb').read(),
                    MetadataItem=[self.factory_xsd_common.MetadataItemType(
                        Key='KeyExample',
                        Value='ValueExample',
                        Target=self.factory_xsd_common.TargetEnumeration("MIR")
                    )]
                )
            ],

            MetadataItem=[
                # Not setting the target will be interpreted as Target is NONE.
                # Therefore this metadata item will not be passed back in the
                # result.
                self.factory_xsd_common.MetadataItemType(
                    Key='KeyExampleOne',
                    Value="ValueExampleOne"
                ),

                # This meta data item will be passed back in the result because
                # the target is set to RESULT.
                self.factory_xsd_common.MetadataItemType(
                    Key='KeyExampleTwo',
                    Value="ValueExampleTwo",
                    Target=self.factory_xsd_common.TargetEnumeration("RESULT")
                )
            ]
        )

        return [passage]

    def enqueue_passages(self, passages):
        """Enqueue one or more passages

        Upon enqueuing the passages, Intrada Insight will send back an acknowledgement for each passage.
        This acknowledgement contains the following:
            1) HostPassageID: The ID this client gave to the passage;
            2) IssPassageID: The ID Intrada Insight gave to the passage. This is the id that will be used in almost all future
               communications regarding this passage. This field is only available with the OK-status;
            3) Status: The status; was the passage accepted (OK), rejected (REJECT), or should this client send it again
               (RETRY);
            4) Description: An optional description containing more information.

        :param passages: The passages to enqueue
        :type passages: list
        """

        to_be_enqueued_passages = copy.deepcopy(passages)

        while len(to_be_enqueued_passages) > 0:
            acknowledgements = self.client.service.EnqueuePassages(Passage=to_be_enqueued_passages)

            to_be_enqueued_passages = []

            # Check the status of every enqueued passage and act accordingly
            for acknowledgement in acknowledgements:
                status = acknowledgement._value_1

                if status == "OK":
                    # When the status is "OK", the passage has successfully been enqueued. You should save a mapping
                    # between the acknowledgement.IssPassageID and acknowledgement.HostPassageID here.
                    print("Successfully enqueued passage with HostID '{}' and "
                          "PassageID '{}'".format(acknowledgement.HostPassageID, acknowledgement.IssPassageID))
                    continue

                if status == "REJECT":
                    # The status is "REJECT": This usually means that the data is invalid. You should do error handling
                    # here. See acknowledgement.Description for more detailed information on the error.
                    # NOTE: The IssPassageID is not available at this point
                    print("Could not enqueue passage with HostID '{}': {}"
                          .format(acknowledgement.HostPassageID, acknowledgement.Description))
                    continue

                if status == "RETRY":
                    # A retry status means that the data was valid, but that Intrada Insight could not process
                    # the data right now. As such, we should try to resend the data.
                    # NOTE: The IssPassageID is not available at this point
                    print("Scheduling passage with HostId '{}' for retry"
                          .format(acknowledgement.HostPassageID))
                    to_be_enqueued_passages.append(
                        next(p for p in passages if p['HostPassageID'] == acknowledgement.HostPassageID))

                    continue

                # If to_be_enqueued_passages is not empty then some passages where scheduled for a retry
                if len(to_be_enqueued_passages) > 0:
                    time.sleep(1)


if __name__ == '__main__':
    try:
        enqueue_passages_client = EnqueuePassages()
        enqueue_passages_client.run()
    except Exception as e:
        print(e)
    finally:
        print('Press enter to close the application.')
        input()
