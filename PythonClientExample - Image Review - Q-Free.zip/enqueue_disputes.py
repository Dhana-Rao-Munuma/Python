import requests
from zeep import Client
from zeep import Transport
import datetime
import uuid
import copy
import time

from zeep.exceptions import Fault

# The username that is used to connect to Intrada Insight
username = '[USERNAME]'

# The password that corresponds with the username
password = '[PASSWORD]'

# The url of the Passage Service. [Intrada Insight URL] is a placeholder of the URL that point to the Intrada Insight
# installation
iss_url = 'https://[Intrada Insight URL]/PassageService.wsdl'

# The identifier of the previously identified passage that is issued by the host.
host_passage_id = '[HOSTPASSAGEID]'

# The (UUID4) identifier of the previously identified passage that is issued by Intrada Insight.
original_iss_passage_id = uuid.uuid4()

# The type of dispute.
dispute_category = 'CUSTOMER_COMPLAINT_MISREAD'

# The reason why the dispute is issued.
dispute_reason = '[REASON]'

# The result type of the original identification.
original_identification_result_type = None

# The time that the original identification was completed.
original_completion_time_utc = None

# The original registration.
original_registration = '[REGISTRATION]'

# The original jurisdiction.
original_jurisdiction = '[JURISDICTION]'


class EnqueueDisputes:
    """PassageService.EnqueueDisputes code integration example"""
    
    def __init__(self):
        """Initialize an instance of EnqueueDisputes
        
        This method creates a client with the provided credentials and connects this client to the Intrada Synergy
        Server instance that is hosted on the provided URL. Additional types are imported by type factories in order to
        ease the creation of types that are required by Intrada Insight.
        """
        
        session = requests.Session()
        session.auth = requests.auth.HTTPBasicAuth(username, password)
        transport = Transport(session=session)
        self.client = None
        
        try:
            self.client = Client(iss_url, transport=transport)
            print('Created client')
        except requests.exceptions.HTTPError as http_error:
            print('Could not create client due to HTTPError: {0}'.format(http_error))
            
        self.factory_xsd_common = self.client.type_factory('ns1')
        self.factory_xsd_passage = self.client.type_factory('ns2')
    
    def run(self):
        """Run the PassageService.EnqueueDisputes client

        This method builds disputes and sends those disputes to Intrada Insight.
        """
        
        try:
            disputes = self.build_disputes()
            self.enqueue_disputes(disputes)
        except Fault as fault:
            print(fault.message)
            print(fault.code)
            
            if fault.detail is not None:
                self.print_node(fault.detail)
    
    def print_node(self, node):
        """Recursively print the text of every node

        :param node: The node
        """

        for child_node in node:
            self.print_node(child_node)

        if node.text is not None:
            print(node.text)
    
    def build_disputes(self):
        """Build a list with one dispute

        :return: A list with one dispute
        :rtype: list
        """
        
        # Represents a dispute
        dispute = self.factory_xsd_passage.DisputePassageType(
            
            # The different identifiers of the previously identified passage.
            # Note: Either one or both are required.
            HostPassageID=host_passage_id,
            IssPassageID=str(original_iss_passage_id),
            
            # Information data about the dispute.
            DisputeWorkflowDetails=self.factory_xsd_common.DisputeWorkflowDetailType(
                
                # The type of dispute.
                # Note: Is required.
                DisputeCategory=dispute_category,
                
                # The reason why the dispute is issued.
                DisputeReason=dispute_reason,
                
                # Information about the identification.
                OriginalIdentification=self.factory_xsd_common.OriginalIdentificationType(
                    
                    # The original registration.
                    Registration=original_registration,
                    
                    # The original jurisdiction.
                    Jurisdiction=original_jurisdiction,
                    
                    # The original plate type.
                    PlateType="",
                    
                    # The result of the original identification.
                    Type=original_identification_result_type,
                    
                    # The timestamp that the original identification was completed.
                    OriginalCompletionTimeUTC=original_completion_time_utc,
                    
                    # Information about the image that the original identification is based on
                    ImageOfRecord=self.factory_xsd_common.ImageOfRecordType(
                        
                        # The HostImageID of the image.
                        None,
                        
                        # The location of the bottom part of the region of interest on the image.
                        RoiBottom=0,
                        
                        # The location of the left part of the region of interest on the image.
                        RoiLeft=0,
                        
                        # The location of the right part of the region of interest on the image.
                        RoiRight=0,
                        
                        # The location of the top part of the region of interest on the image.
                        RoiTop=0
                    ),
                    
                    # Information about the vehicle.
                    Vehicle=self.factory_xsd_common.VehicleType(
                        
                        # The make of the vehicle.
                        Make='',                        
                        
                        # The model of the vehicle.
                        Model='',                        
                        
                        # The color of the vehicle.
                        Color=''
                    )
                )
            )            
        )
        
        return [dispute]
    
    def enqueue_disputes(self, disputes):
        """ Enqueue one or more disputes
        
        # Upon enqueueing the dispute passages, Intrada Insight returns an acknowledgement for each
        # dispute passage.
        #
        # The acknowledgement is returned with 'Status.OK':
        # - HostPassageID: The HostPassageID of the original identified passage.
        # - OriginalIssPassageID: The IssPassageID of the original identified passage.
        # - IssPassageID: A new unique IssPassageID issued by Intrada Insight.
        # - Status: OK.
        # - Description: Empty.
        #
        # The acknowledgement is returned with 'Status.RETRY' or 'Status.REJECT':
        # - HostPassageID: The HostPassageID of the original identified passage, this could be empty if
        #                  not supplied with the dispute passage.
        # - OriginalIssPassageID: The IssPassageID of the original identified passage, this could be
        #                         empty if not supplied with the dispute passage.
        # - IssPassageID: Not used, no new unique IssPassageID is issued by Intrada Insight.
        # - Status: RETRY or REJECT.
        # - Description: Description about why the RETRY or REJECT is returned.
        
        :param disputes: The disputes to enqueue
        :return: list
        """
        
        to_be_enqueued_disputes = copy.deepcopy(disputes)
        
        while len(to_be_enqueued_disputes) > 0:
            acknowledgements = self.client.service.EnqueueDisputes(DisputePassage=to_be_enqueued_disputes)
            
            to_be_enqueued_disputes = []
            
            # Check the status of every enqueued dispute passage and act accordingly.
            for acknowledgement in acknowledgements:
                status = acknowledgement._value_1
                                
                if status == "OK":
                    # The dispute passage is successfully enqueued.
                    print("Successfully enqueued dispute with "
                          "(HostID '{}' - IssID '{}'), new IssID is '{}'".format(acknowledgement.HostPassageID, acknowledgement.OriginalIssPassageID, acknowledgement.IssPassageID))
                    continue
                
                if status == "REJECT":
                    # Either the dispute passage has invalid data, the requested passage is not archived or
                    # the Intrada Insight system is not configured to support this.
                    # See acknowledgement.Description for more information.
                    print("Could not enqueue dispute with "
                          "(HostID '{}' - IssID '{}'): {}".format(acknowledgement.HostPassageID, acknowledgement.OriginalIssPassageID, acknowledgement.Description))
                    continue
                    
                if status == "RETRY":
                    # Intrada Insight could not process the dispute passage right now. As such, we should
                    # try to resend the dispute passage.
                    # NOTE: The IssPassageID is not available at this point
                    print("Scheduling dispute with "
                          "(HostID '{}' - IssID '{}') for retry".format(acknowledgement.HostPassageID, acknowledgement.OriginalIssPassageID))
                    to_be_enqueued_disputes.append(
                        next(d for d in disputes if (d['HostPassageID'] == acknowledgement.HostPassageID or d['IssPassageID'] == acknowledgement.OriginalIssPassageID))
                    )

                # If to_be_enqueued_disputes is not empty then some disputes where scheduled for a retry
                if len(to_be_enqueued_disputes) > 0:
                    time.sleep(1)


if __name__ == '__main__':
    try:
        enqueue_disputes_client = EnqueueDisputes()
        enqueue_disputes_client.run()
    except Exception as e:
        print(e)
    finally:
        print('Press enter to close the application')
        input()