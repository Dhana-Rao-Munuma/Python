import requests
from zeep import Client
from zeep import Transport
from zeep.exceptions import Fault
import copy
import time

# The username that is used to connect to Intrada Insight
username = '[USERNAME]'

# The password that corresponds with the username
password = '[PASSWORD]'

# The url of the Passage Service. [Intrada Insight URL] is a placeholder of the URL that point to the Intrada Insight
# installation
iss_url = 'https://[Intrada Insight URL]/PassageService.wsdl'

# The maximum number of results that we will retrieve at the same time
batch_size = 10


class GetResults:
    """PassageService.GetResults code integration example"""

    def __init__(self):
        """Initialize an instance of GetResults

        This methods creates a client with the provided credentials and connects this client to the Intrada Synergy
        Server instance that is hosted on the provided URL.
        """

        session = requests.Session()
        session.auth = requests.auth.HTTPBasicAuth(username, password)
        transport = Transport(session=session)
        self.client = None

        try:
            self.client = Client(iss_url, transport=transport)
            print('Created client')
        except requests.exceptions.HTTPError as http_error:
            print('Could not create client due to HTTPError: {0}'.format(http_error))

    def run(self):
        """Run the PassageService.GetResults client

        This method retrieves results and sends acknowledgements for these results.
        """

        try:
            results = self.get_results(batch_size)

            if results is not None:
                self.acknowledge_results(results)
        except Fault as fault:
            print(fault.message)
            print(fault.code)

            if fault.detail is not None:
                self.print_node(fault.detail)

    def print_node(self, node):
        """Recursively print the text of every node

        :param node: The node
        """

        for child_node in node:
            self.print_node(child_node)

        if node.text is not None:
            print(node.text)

    def get_results(self, max_results):
        """Retrieve the results

        Since Intrada Insight is an asynchronous system, results will not necessary be directly available. As such, one should
        continuously keep requesting new results.

        :return: List of results or None
        :rtype: list
        """

        results = self.client.service.GetResults(MaxResults=max_results)

        if len(results) < 1:
            print('Got 0 results')
            return None

        for result in results:
            if result.Plate is not None:
                print('Got a result for passage with IssPassageID {}. Registration: {}, Jurisdiction: {}, Confidence: '
                      '{}'.format(result.IssPassageID, result.Plate.Registration, result.Plate.Jurisdiction,
                                  result.Plate.Confidence))
            else:
                print('Got a result for passage with IssPassageID {}: No identification'.format(result.IssPassageID))

            if result.MetadataItem is None:
                continue

            driving_direction = next((m for m in result.MetadataItem if m.Key == 'DrivingDirection'), None)

            if driving_direction is not None:
                print('Driving direction: {}'.format(driving_direction.Value))

        return results

    def acknowledge_results(self, results):
        """Send an acknowledgement of the results

        To make sure that each result was correctly received, the host should send an acknowledgement of the results.
        This acknowledgement contains the following:
            1) IssPassageID: The passage to acknowledge the result for;
            2) Status: The status; was the result accepted (OK), rejected (REJECT), or should Intrada Insight
               send it again (RETRY).

        Upon receiving this data, Intrada Insight will send an acknowledgemt back (the double acknowledgement). This contains,
        alongside with the status and IssPassageID, an optional description giving a reason for the status.

        :param results: The results of passages
        :type results: list
        """

        acknowledgements = list(map(lambda result: {
            'IssPassageID': result['IssPassageID'],

            # The status defines whether we (the host) have accepted the result If the status is set to "RETRY",
            # Intrada Insight will present the result again in the future. If the status is "OK" or "REJECT", the result will not
            # be presented again. The main difference is that with an "REJECT", the result will end up in the
            # poison-queue; waiting for manual support. One reason to reject the result for example, is when the
            # IssPassageId is unknown to us (the host)
            '_value_1': 'OK'}, results))

        to_be_acknowledged = copy.deepcopy(acknowledgements)

        while len(to_be_acknowledged) > 0:

            acknowledge_results = self.client.service.AcknowledgeResults(Acknowledgement=to_be_acknowledged)

            to_be_acknowledged = []

            # Check the status of every send acknowledgement and act accordingly
            for acknowledge_result in acknowledge_results:
                status = acknowledge_result._value_1

                if status == 'OK':
                    # When the status is "OK", the acknowledgement has been accepted. There is nothing you should do
                    # here.
                    print('Successfully acknowledged result of passage with PassageID {}'.format(
                        acknowledge_result.IssPassageID))
                    continue

                if status == 'REJECT':
                    # The status is "REJECT": This usually means that the data is invalid. You should do error handling
                    # here. See acknowledgeResult.getDescription() for more detailed information on the error.
                    print('Could not acknowledge result of passage with PassageID {}: {}'.format(
                        acknowledge_result.IssPassageID, acknowledge_result.Description))
                    continue

                if status == "RETRY":
                    # A retry status means that the data was valid, but that Intrada Insight could not process the data right now.
                    # As such, we should try to resend the acknowledgement.
                    print('Scheduling acknowledgement of passage with PassageID {} for retry'
                          .format(acknowledge_result.IssPassageID))

                    to_be_acknowledged.append(
                        next(ack for ack in acknowledgements if ack['IssPassageID'] == acknowledge_result.IssPassageID))

                    continue

            # If we scheduled passages for a retry, sleep and try to send them
            # again
            if len(to_be_acknowledged) > 0:
                time.sleep(1)


if __name__ == '__main__':
    try:
        get_results_client = GetResults()
        get_results_client.run()
    except Exception as e:
        print(e)
    finally:
        print('Press enter to close the application.')
        input()
